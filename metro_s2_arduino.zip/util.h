#include <Arduino.h>

void printhex(uint8_t val);
